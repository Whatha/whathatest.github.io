A Pen created at CodePen.io. You can find this one at http://codepen.io/Mamboleoo/pen/XgBvrJ.

 I saw the hover effect on the links of this [page](http://www.climber.io/) and I wanted to reproduce them :)