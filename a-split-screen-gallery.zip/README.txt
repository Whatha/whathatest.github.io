A Pen created at CodePen.io. You can find this one at http://codepen.io/eduardoboucas/pen/qdaOWv.

 A split screen gallery for telling a story or showing a slideshow. It's buggy on iOS because of the way it deals with fixed positioned elements.